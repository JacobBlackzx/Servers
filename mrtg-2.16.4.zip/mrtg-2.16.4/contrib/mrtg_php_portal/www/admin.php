<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title>MRTG remove switch:</title>
</head>

<body>

<p><u><b>Configuration:</b></u></p>
<ul>
  <li><a href="setup.php">Add a switch</a></li>
  <li><a href="remove.php">Remove a switch</a></li>
  <li><a href="update.php">Update MRTG statistics</a></li>
</ul>
<br><a href=./>Back to index</a>
</body>

</html>